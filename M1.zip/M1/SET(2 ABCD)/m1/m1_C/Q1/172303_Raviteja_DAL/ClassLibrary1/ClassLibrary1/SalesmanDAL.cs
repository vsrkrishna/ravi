﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesMan_Entity ;
using Exceptions;
namespace Sales_DAL
{
    
    public class SalesmanDAL
    {
        public static List<Salesman> SalesmanList = new List<Salesman>();
        
        //Adding the salesman to the list and in return it is giving whether it is adding or not with a boolean value

        public  bool AddSalesmanDAL(Salesman newSalesman)
        {
            bool SalesmanAdded = false;
            try
            {
                SalesmanList.Add(newSalesman);
                SalesmanAdded = true;
            }
            catch (SystemException ex)
            {
                throw new SalesmanNotFoundException(ex.Message);
            }
            return SalesmanAdded;
        }
        // searching salesman
        public Salesman SearchSalesmanDAL(string searchname)
        {
            Salesman searchSalesman = null;
            try
            {
                searchSalesman =SalesmanList.Find(salesman=> salesman.Name == searchname);
            }
            catch (SalesmanNotFoundException ex)
            {
                throw new SalesmanNotFoundException(ex.Message);
            }
            return searchSalesman;
            
        }
        //when the bal calls this method it will return the list of salesman

        public List<Salesman> GetAllSalesmanDAL()
        {
            return SalesmanList;
        }
        //serializing all the data in the list  and creating a filesalesmanDetails.Dat
        public bool SerializeDataDAL(Salesman newSalesman)

        {
            if (newSalesman == null)
            {
                throw new ArgumentNullException(nameof(newSalesman));
            }

            bool SalesmanSerialized = false;

            try

            {

                SalesmanList.Add(newSalesman);

                SalesmanSerialized = true;

                FileStream fs = new FileStream("SalesmanDetails.dat", FileMode.Create);

                BinaryFormatter bff = new BinaryFormatter();

                bff.Serialize(fs, SalesmanList);

                fs.Close();

            }

            catch (Exception ex)

            {

                throw new  SalesmanNotFoundException(ex.Message);

            }

            return SalesmanSerialized;

        }
        //it will return all the data stored in the salesman details
        public List<Salesman> DeserializeDataDAL()

        {

            //Reading file named "SalesDetails.dat"

            FileStream fs = new FileStream("SalesmanDetails.dat", FileMode.Open);

            BinaryFormatter bff = new BinaryFormatter();

            List<Salesman> SalesmanList = bff.Deserialize(fs) as List<Salesman>;

            fs.Close();

            return SalesmanList;

        }

    }
}
