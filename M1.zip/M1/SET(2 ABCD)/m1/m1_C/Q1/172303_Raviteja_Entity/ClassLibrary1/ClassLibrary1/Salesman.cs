﻿/*
 * empid:172303
 * authorname:raviteja
 * file:SalesmanPrograam
 * Creation date:12-2-2019
 * */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SalesMan_Entity
{
    
    public class Salesman
    {
        private int salesmanCode;
        public int SalesManCode { get; set; }
        public string Name { get; set; }
        public string Region { get; set; }
        public int TargetSet { get; set; }
        public int ActualSales { get; set; }
        public object GuestID { get; set; }
    }
}
