﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{


    [Serializable]
    public class SalesmanNotFoundException : Exception
    {
        public SalesmanNotFoundException() { }
        public SalesmanNotFoundException(string message) : base(message) { }
        public SalesmanNotFoundException(string message, Exception inner) : base(message, inner) { }
        protected SalesmanNotFoundException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
