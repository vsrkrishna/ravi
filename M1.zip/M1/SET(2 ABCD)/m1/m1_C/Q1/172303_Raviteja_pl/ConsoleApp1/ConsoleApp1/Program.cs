﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesMan_Entity;
using Exceptions;
using Sales_BAL;
using System.Text.RegularExpressions;

namespace MainProgram
{
   
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddSalesman();
                        break;
                    case 2:
                        SerializeData();
                        break;
                    case 3:
                        DeserializeData();
                        break;
                    case 4:
                        SearchSalesmanByName();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
        //for searching the salesman
        private static void SearchSalesmanByName()
        {
            try
            {
                string salesmanname;
                Console.WriteLine("Enter name to Search:");
                salesmanname = Console.ReadLine();
                Salesman searchName = SalesmanBAL.SearchSalesmanBAL(salesmanname);
                if (searchName != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchName.Name, searchName.SalesManCode, searchName.Region,searchName.TargetSet,searchName.ActualSales);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No salesman Details Available");
                }

            }
            catch (SalesmanNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //for adding the salesman
        private static void AddSalesman()
        {
            try
            {
                Salesman newSalesman = new Salesman();

                Console.WriteLine("Enter Salesman Name :");
                newSalesman.Name = Console.ReadLine();

                Console.WriteLine("Enter Salesman code :");
                newSalesman.SalesManCode = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Region:");
                newSalesman.Region = Console.ReadLine();

                Console.WriteLine("Enter TargetSet :");
                newSalesman.TargetSet = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Actual Sales:");
                newSalesman.ActualSales = Convert.ToInt32(Console.ReadLine());

             

                bool SalesmanAdded = SalesmanBAL.AddSalesmanBL(newSalesman);
                if (SalesmanAdded)
                    Console.WriteLine("Client Added");
                else
                    Console.WriteLine("Client not Added");
            }
            catch (SalesmanNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Client Visit Menu***********");
            Console.WriteLine("1. Add Salesman");
            Console.WriteLine("2. Searialize SalesMan");
            Console.WriteLine("3. DeSearialize SalesMan");
            Console.WriteLine("4. Search Salesman");
            Console.WriteLine("5. Exit");

            Console.WriteLine("******************************************\n");

        }
        private static void SerializeData()

        {

            try

            {
                Salesman newSalesman = new Salesman();

                Console.WriteLine("Enter Salesman Name :");
                newSalesman.Name = Console.ReadLine();

                Console.WriteLine("Enter Salesman code :");
                newSalesman.SalesManCode = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Region:");
                newSalesman.Region = Console.ReadLine();

                Console.WriteLine("Enter TargetSet :");
                newSalesman.TargetSet = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Actual Sales:");
                newSalesman.ActualSales = Convert.ToInt32(Console.ReadLine());

                bool SalesmanSerialized = Sales_BAL.SalesmanBAL.SerializeDataBL(newSalesman);

                if (SalesmanSerialized)

                    Console.WriteLine("Salesman Serialized");

                else

                    Console.WriteLine("Salesman not Serialized");

            }

            catch (SalesmanNotFoundException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }
        private static void DeserializeData()

        {

            try

            {

                List<Salesman> SalesmanList = Sales_BAL.SalesmanBAL.DeserializeDataBL();

                if (SalesmanList != null && SalesmanList.Count > 0)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("******************************************************************************");

                    foreach (Salesman salesman in SalesmanList)

                    {

                        Console.WriteLine("{0}\t\t\t{1}\t\t{2}\t\t{3}\t\t{4}", salesman.Name, salesman.SalesManCode, salesman.Region, salesman.TargetSet, salesman.ActualSales);

                    }

                    Console.WriteLine("******************************************************************************");

                }

                else

                {

                    Console.WriteLine("No Serialized Data Available");

                }

            }

            catch (SalesmanNotFoundException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }

    }
}
