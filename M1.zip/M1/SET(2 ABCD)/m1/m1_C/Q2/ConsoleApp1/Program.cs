﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace ConsoleApp1
{
    public class Program
    {
        public int rollno { get; set; }
        public string Name { get; set; }
        public int myField1 = 0;
        protected string myField2 = null;
        public static void Main()
        {
            FieldInfo[] myFieldInfo;
            Type myType = typeof(Program);
            // Get the type and fields of FieldInfoClass.
            myFieldInfo = myType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public);
            Console.WriteLine("\nThe fields of " + "FieldInfoClass are \n");
            // Display field information of FieldInfoClass.
            for (int i = 0; i < myFieldInfo.Length; i++)
            {
                Console.WriteLine("\nName            : {0}", myFieldInfo[i].Name);
                Console.WriteLine("Declaring Type  : {0}", myFieldInfo[i].DeclaringType);
                Console.WriteLine("IsPublic        : {0}", myFieldInfo[i].IsPublic);
                Console.WriteLine("MemberType      : {0}", myFieldInfo[i].MemberType);
                Console.WriteLine("FieldType       : {0}", myFieldInfo[i].FieldType);
                Console.WriteLine("IsFamily        : {0}", myFieldInfo[i].IsFamily);
            }
            //to get properties call prop method
            Program p = new Program();
            p.prop();
            p.Construct();

        }
        public void prop()
        {
            rollno = 7;
            Name = "ravi";
            Program programInstance = new Program();
            Type myType = typeof(Program);
            foreach (PropertyInfo propertyInfo in myType.GetProperties())
            {
                // Get name.
                string name = propertyInfo.Name;

                // Get value on the target instance.
                object value = propertyInfo.GetValue(programInstance, null);

                // Test value type.
                if (value is int)
                {
                    Console.WriteLine("Int: {0} = {1}", name, value);
                }
                else if (value is string)
                {
                    Console.WriteLine("String: {0} = {1}", name, value);
                }
            }
        }
        public Program()
        {
            int a = 10;
        }
        public Program(int i)
        {
            int b = i;
        }
        public void Construct()
        {
            Type t = typeof(Program);


            ConstructorInfo[] ci = t.GetConstructors();

            Console.WriteLine("Available constructors: ");
            foreach (ConstructorInfo c in ci)
            {

                Console.Write("   " + t.Name + "(");

                // Display parameters. 
                ParameterInfo[] pi = c.GetParameters();

                for (int i = 0; i < pi.Length; i++)
                {
                    Console.Write(pi[i].ParameterType.Name + " " + pi[i].Name);
                    if (i + 1 < pi.Length)
                        Console.Write(", ");
                }

                Console.WriteLine(")");
            }
        }
    }
}
   