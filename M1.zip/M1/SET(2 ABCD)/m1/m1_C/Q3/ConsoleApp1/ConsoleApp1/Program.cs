﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp1
{
    class Program
    {
        //Defining Properties

        public static int ManagerId { get; set; } = 1001;

        public static string Name { get; set; } = "Suresh";

        public static void print() => Console.WriteLine("managerId : {0} Name : {1}", ManagerId, Name);


        static void Main(string[] args)
        {
            //Calling Print function

            print();

            Console.ReadLine();
        }
    }
}
