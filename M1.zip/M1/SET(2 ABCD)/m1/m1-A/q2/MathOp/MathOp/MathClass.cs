﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
namespace MathOp
{
    class MathClass
    {
        static void Main(string[] args)
        {
            int num1, num2;
            int op;
            int sum, sub;
            MathOp c1 = new MathOp();
            //Taking the two integer values from the user
            Console.WriteLine("Enter 2 int values");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            //user will enter which operation to be performed
            Console.WriteLine("Enter the operation to be performed");
            op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1:
                    int sum1 = num1 + num2;
                    object o=sum1;
                    
                    //adding two numbers
                    Console.WriteLine($"{num1}+{num2}={sum1}");

                    break;
                case 2:
                    int sum2 = num1 - num2;
                    object o1 = sum2;
                    //subracting two numbers
                    Console.WriteLine($"{num1}-{num2}={sum2}");

                    break;

            }
            Console.ReadKey();
        }
    }
}
