﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
namespace MathOp
{
    class MathOp:MathClass
    {
        int num1, num2;
        //add method making it abstract
       // abstract public int Add();
       
        public void Addition(int num1,int num2)

        {

            Console.WriteLine(num1 + num2);

        }
        //sub method making it abstract
       // abstract public int Sub();

        public void Subtraction(int num1, int num2)

        {

            Console.WriteLine(num1 - num2);

        }
    }
}
