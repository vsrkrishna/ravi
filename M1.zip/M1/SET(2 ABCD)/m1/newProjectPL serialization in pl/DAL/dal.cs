﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Entity;
using Exception;
using System.Runtime.Serialization.Formatters.Binary;


namespace DAL
{
    public class dal
    {
        public static List<entityclass> st = new List<entityclass>();

        public bool Add_dal(entityclass student)
        {
            bool studAdded = false;
            try
            {
                st.Add(student);
                studAdded = true;
            }
            catch (studentNOTfoundException ex)
            {
                throw ex;
            }
            return studAdded;
        }

        public List<entityclass> GetAll_dal()
        {
            return st;
        }


        public bool Deletestud_dal(int deletestudId)
        {
            bool studentDeleted = false;
            try
            {
                entityclass student = st.Find(p => p.studId == deletestudId);
                int index = st.IndexOf(student);
                st.RemoveAt(index);
                studentDeleted = true;
            }
            catch (studentNOTfoundException ex)
            {
                throw new studentNOTfoundException(ex.Message);
            }
            return studentDeleted;

        }


        public entityclass searchstud_dal(int studId)
        {
            try
            {
                entityclass searchstud = null;
                foreach (var student in st)
                {
                    if (student.studId == studId)
                    {
                        searchstud = student;
                    }

                }
                return searchstud;
            }
            catch (studentNOTfoundException ex)
            {
                throw ex;
            }

        }

        public bool Updatestud_dal(entityclass updatestudent)
        {
            bool patientUpdated = false;
            try
            {
                entityclass student = st.Find(p => p.studId == updatestudent.studId);
                int index = st.IndexOf(student);
                st[index] = updatestudent;
                patientUpdated = true;
            }
            catch (studentNOTfoundException ex)
            {
                throw new studentNOTfoundException(ex.Message);
            }
            return patientUpdated;
        }


        public static bool SerializeData()
        {

            //FileStream stream;
            try
            {
                FileStream fs = new FileStream("StudentntDetails.dat", FileMode.Create);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, st);
               fs.Close();
            }
            catch (studentNOTfoundException ex)
            {
                throw ex;
            }
            return true;
        }

        public static List<entityclass> DeserializeData()
        {
            FileStream stream = new FileStream("StudentntDetails.dat", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            st = formatter.Deserialize(stream) as List<entityclass>;
            return st;
        }

    }
}
