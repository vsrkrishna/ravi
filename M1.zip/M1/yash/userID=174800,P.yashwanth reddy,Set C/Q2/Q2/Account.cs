﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    //Creating an delegate for method
    public delegate void MakePaymentHandler(string message);
    class Account
    {
        //creating properties for class
        public long CreditCardNo;
        public string CardHolderName;
        public double BalanceAmount=2000;
        public event MakePaymentHandler PaymentSuccessful = null;
        public void Deposit(double amount)
        {
            BalanceAmount += amount;
        }

            //created withdraw method
            public double Withdraw(double amount,string msg)
        {
            double Balance = BalanceAmount - amount;

            if (Balance <=1000)
            {
                PaymentSuccessful(msg);
            }
            return Balance;
        }
    }
}
