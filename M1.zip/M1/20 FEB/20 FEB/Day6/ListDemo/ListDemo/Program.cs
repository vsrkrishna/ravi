﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListDemo
{
    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numList = new List<int>();
            numList.Add(23);
            numList.Add(78);
            numList.Add(34);

            List<string> strList = new List<string>();
            strList.Add("Pune");
            strList.Add("Mumbai");
            strList.Add("Bangalore");

            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() { ID = 101, Name = "Robert" });
            empList.Add(new Employee() { ID = 102, Name = "John" });
            empList.Add(new Employee() { ID = 103, Name = "Maria" });

            foreach (var emp in empList)
            {
                Console.WriteLine(emp.ID + "\t" + emp.Name);
            }

            Console.ReadKey();
        }
    }
}
