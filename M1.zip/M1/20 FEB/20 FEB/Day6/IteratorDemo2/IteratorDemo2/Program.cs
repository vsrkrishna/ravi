﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo2
{
    class Program
    {
        public IEnumerable Power(int num, int pow)
        {
            int result = 1;
            for (int i = 1; i <= pow; i++)
            {
                result = result * num;
                yield return result;
            }
        }
        static void Main(string[] args)
        {
            Program p = new Program();

            //Console.WriteLine(p.Power(2, 8));

            foreach (var pow in p.Power(2, 8))
            {
                Console.WriteLine(pow);
            }
            
            Console.ReadKey();
        }
    }
}
