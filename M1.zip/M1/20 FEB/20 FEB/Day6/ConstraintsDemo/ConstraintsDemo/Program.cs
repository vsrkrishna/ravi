﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstraintsDemo
{
    public class MyClass<T> where T : class
    { }

    public struct DOB
    {
        public int DD { get; set; }
        public int MM { get; set; }
        public int YYYY { get; set; }
    }

    public class Employee { }
    class Program
    {
        static void Main(string[] args)
        {
            MyClass<int> objInt = new MyClass<int>();
            MyClass<DateTime> objDate = new MyClass<DateTime>();
            MyClass<double> objDouble = new MyClass<double>();
            MyClass<DOB> objDOB = new MyClass<DOB>();

            MyClass<string> objStr = new MyClass<string>();
            MyClass<StringBuilder> objSb = new MyClass<StringBuilder>();
            MyClass<Array> objArr = new MyClass<Array>();
            MyClass<Employee> objEmp = new MyClass<Employee>();
        }
    }
}
