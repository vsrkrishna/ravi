﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace HashtableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable ht = new Hashtable();
            ht.Add(1, "Pune");
            ht.Add(2, "Mumbai");
            ht.Add(3, "Bangalore");
            ht.Add(4, "Hyderabad");
            ht.Add(5, "Chennai");
            ht.Add(6, "Pune");
            ht.Add(7, null);

            Console.WriteLine("HashTable Data : ");
            foreach (object key in ht.Keys)
            {
                Console.WriteLine($"Key : {key}\tValue : {ht[key]}");
            }
                        
            Console.ReadKey();
        }
    }
}
