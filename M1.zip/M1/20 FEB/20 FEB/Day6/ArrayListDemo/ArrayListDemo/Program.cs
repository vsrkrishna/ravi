﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ArrayListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrList = new ArrayList();

            arrList.Add(10);
            arrList.Add("Capgemini");
            arrList.Add(false);
            arrList.Add(Math.PI);
            arrList.Add(".NET");
            arrList.Add(123434);
            arrList.Add(344.67);
            arrList.Add('C');
            arrList.Add(1);

            Console.WriteLine($"Number of elements: {arrList.Count}");
            Console.WriteLine($"Capacity is : {arrList.Capacity}");

            Console.WriteLine("ArrayList elements are : ");
            for (int i = 0; i < arrList.Count; i++)
            {
                Console.Write(arrList[i] + "\t");
            }

            object[] arr = new object[15];
            //CopyTo(Array)
            //Copy all elements from array list 
            //and paste these elements inside the array 
            //from index 0
            //arrList.CopyTo(arr);

            //CopyTo(Array, index)
            //Copy all elements from array list
            //and paste these elements inside array
            //from the provided index
            //arrList.CopyTo(arr, 3);

            //CopyTo(ArrayListIndex, Array, ArrayIndex, NumberofElements)
            //Copy elements from array list from index ArrayListIndex
            //and paste in array from arrayIndex position
            //and only the numberofelements will be pasted
            arrList.CopyTo(3, arr, 5, 4);

            Console.WriteLine("\n\nArray Elements are : ");
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] != null)
                    Console.WriteLine(arr[i]);
                else
                    Console.WriteLine("Empty");
            }
            
            Console.ReadKey();
        }
    }
}
