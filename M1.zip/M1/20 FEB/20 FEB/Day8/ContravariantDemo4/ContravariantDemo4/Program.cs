﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContravariantDemo4
{
    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int DeptID { get; set; }

        public Employee(int id, string name, int deptid)
        {
            ID = id;
            Name = name;
            DeptID = deptid;
        }
    }

    class Manager : Employee
    {
        public double Incentives { get; set; }

        public Manager(int id, string name, int deptid, double inc) : base(id, name, deptid)
        {
            Incentives = inc;
        }
    }

    class EmployeeComparer : IComparer<Employee>
    {
        public int Compare(Employee x, Employee y)
        {
            if (x.DeptID > y.DeptID)
                return 1;
            else if (x.DeptID < y.DeptID)
                return -1;

            return 0;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee(101, "Robert", 30));
            empList.Add(new Employee(102, "Rosy", 10));
            empList.Add(new Employee(103, "William", 30));
            empList.Add(new Employee(104, "Albert", 40));
            empList.Add(new Employee(105, "Walt", 20));
            empList.Add(new Employee(106, "Robin", 30));
            empList.Add(new Employee(107, "Ruby", 10));

            EmployeeComparer empComparer = new EmployeeComparer();
            empList.Sort(empComparer);

            foreach (var e in empList)
            {
                Console.WriteLine(e.ID + "\t" + e.Name + "\t" + e.DeptID);
            }

            List<Manager> mgrList = new List<Manager>();
            mgrList.Add(new Manager(201, "Allister", 30, 7878));
            mgrList.Add(new Manager(202, "Alia", 20, 7878));
            mgrList.Add(new Manager(203, "Albert", 30, 7878));
            mgrList.Add(new Manager(204, "Jason", 10, 7878));
            mgrList.Add(new Manager(205, "Tennyson", 40, 7878));
            mgrList.Add(new Manager(206, "Sofia", 30, 7878));
            mgrList.Add(new Manager(207, "Walt", 20, 7878));

            mgrList.Sort(empComparer);

            Console.WriteLine();

            foreach (var m in mgrList)
            {
                Console.WriteLine(m.ID + "\t" + m.Name + "\t" + m.DeptID + "\t" + m.Incentives);
            }

            Console.ReadKey();
        }
    }
}
