﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;       //Reference to Entity Class Library
using EMS.Exception;    //Reference to Exception Class Library
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace EMS.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Date of Creation : 8-Mar-2019
    /// Description : Database operations on Employee Class
    /// </summary>
    public class EmployeeOperations
    {
        static List<Employee> empList = new List<Employee>();

        //To insert the employee record in employee list
        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = false;

            try
            {
                //Adding employee object into employee list
                empList.Add(emp);
                empAdded = true;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

        //To modify the employee data from the list
        public static bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;

            try
            {
                for (int i = 0; i < empList.Count; i++)
                {
                    //Searching employee to update
                    if (empList[i].EmployeeID == emp.EmployeeID)
                    {
                        //Modifying employee details
                        empList[i].EmployeeName = emp.EmployeeName;
                        empList[i].PhoneNo = emp.PhoneNo;
                        empList[i].DOB = emp.DOB;
                        empList[i].DOJ = emp.DOJ;
                        empList[i].City = emp.City;

                        empUpdated = true;
                    }
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        //To delete employee from employee list
        public static bool DeleteEmployee(int empID)
        {
            bool empDeleted = false;

            try
            {
                //Searching employee
                Employee emp = empList.Find(e => e.EmployeeID == empID);

                if (emp != null)
                {
                    //Deleting employee from employee list
                    empList.Remove(emp);
                    empDeleted = true;
                }
                else
                {
                    throw new EmployeeException("Employee with ID " + empID + " does not exist for Delete");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        //To search employee based on employee ID
        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try
            {
                //Searching Employee
                emp = empList.Find(e => e.EmployeeID == empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        //To retrieve all employees
        public static List<Employee> RetrieveEmployees()
        {
            return empList;
        }

        //To Serialize employee list
        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, empList);
                fs.Close();
                empSerialized = true;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        //To deserialize employee List
        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> empDesList = null;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                empDesList = (List<Employee>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDesList;
        }
    }
}
