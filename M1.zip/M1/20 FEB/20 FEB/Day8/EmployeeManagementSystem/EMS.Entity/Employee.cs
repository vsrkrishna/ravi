﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Employee ID : 
    /// Employee Name :
    /// Date of Creation : 8-Mar-2019
    /// Description : Entity class for Employee
    /// </summary>
    [Serializable]
    public class Employee
    {
        //Get or set Employee ID
        public int EmployeeID { get; set; }
        
        //Get or set Employee Name
        public string EmployeeName { get; set; }

        //Get or set Phone Number
        public string PhoneNo { get; set; }

        //Get or set Date of Birth
        public DateTime DOB { get; set; }

        //Get or set Date of Joining
        public DateTime DOJ { get; set; }

        //Get or set City
        public string City { get; set; }
    }
}
