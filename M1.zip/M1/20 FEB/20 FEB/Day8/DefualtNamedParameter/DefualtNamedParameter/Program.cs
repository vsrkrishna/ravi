﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefualtNamedParameter
{
    class Program
    {
        public static void Add(int num1, int num2=20, int num3=30)
        {
            Console.WriteLine($"{num1} + {num2} + {num3} = {num1 + num2 + num3}");
        }
        static void Main(string[] args)
        {
            Add(100);
            Add(100, 200);
            Add(100, 200, 300);
            //Add(100,, 200);

            Add(num3: 200, num1: 300, num2: 100);
            Add(num1: 100, num3: 200);
            //Add(230, num1: 100, num3: 200);

            Console.ReadKey();
        }
    }
}
