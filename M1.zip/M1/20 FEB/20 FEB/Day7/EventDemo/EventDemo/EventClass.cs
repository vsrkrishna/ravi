﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    public delegate void EventHandlerDelegate(string message);

    //Publisher class
    class EventClass
    {
        //Event Declaration
        public event EventHandlerDelegate MyClickEvent;

        //Notification Method
        public void NotifySubscriber(string msg)
        {
            if (MyClickEvent != null)
                MyClickEvent(msg);
        }
    }
}
