﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegateDemo
{
    public delegate void MathDelgate(int num1, int num2);
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();
            //MathDelgate del = new MathDelgate(Calculate.Add);
            MathDelgate del = Calculate.Add;
            del += cal.Subtract;
            del += new MathDelgate(cal.Divide);
            del += Calculate.Add;
            del += Calculate.Multiply;

            del(14, 2);
            Console.WriteLine();

            Delegate[] invList = del.GetInvocationList();
            Console.WriteLine("Methods reffered by Delegate : ");
            for (int i = 0; i < invList.Length; i++)
            {
                Console.WriteLine(invList[i].Method);
            }
            Console.WriteLine();

            del -= Calculate.Add;
            del(15, 3);

            Console.ReadKey();
        }
    }
}
