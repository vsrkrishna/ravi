﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace IDeserializationCallBackDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product(101, "Pen", 30, 100);
            FileStream fs = new FileStream("Product.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, p);
            fs.Close();

            fs = new FileStream("Product.txt", FileMode.Open, FileAccess.Read);
            Product prod = (Product)bin.Deserialize(fs);
            fs.Close();

            Console.WriteLine($"Product ID : {prod.ProductID}");
            Console.WriteLine($"Product Name : {prod.ProductName}");
            Console.WriteLine($"Product Quantity : {prod.Quantity}");
            Console.WriteLine($"Product Price : {prod.Price}");
            Console.WriteLine($"Product Total Price : {prod.Total}");

            Console.ReadKey();
        }
    }
}
