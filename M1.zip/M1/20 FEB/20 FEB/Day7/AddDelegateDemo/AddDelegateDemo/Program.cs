﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddDelegateDemo
{
    public delegate void AddDelegate(int num1, int num2, int num3);
    class Program
    {
        public static void Add(int num1, int num2, int num3)
        {
            Console.WriteLine($"{num1} + {num2} + {num3} => {(num1 + num2 + num3)}");
        }
        static void Main(string[] args)
        {
            AddDelegate mtd = new AddDelegate(Add);
            Console.WriteLine("Output by Add Method");
            mtd(67, 23, 90);

            AddDelegate an = delegate (int num1, int num2, int num3)
            {
                Console.WriteLine($"{num1} + {num2} + {num3} => {(num1 + num2 + num3)}");
            };
            Console.WriteLine("Output by Anonymous Method");
            an(78, 12, 45);

            AddDelegate ld = (num1, num2, num3)=> Console.WriteLine($"{num1} + {num2} + {num3} => {(num1 + num2 + num3)}");
            Console.WriteLine("Output by Lambda Expression");
            ld(89, 34, 67);

            Console.ReadKey();
        }
    }
}
