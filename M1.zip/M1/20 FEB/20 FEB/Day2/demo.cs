public class Hello
{
	public static void Main()
	{
		System.Console.WriteLine("Hello .NET Batch");
	}
}