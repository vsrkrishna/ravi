﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxingUnboxingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 1234;
            object obj = num; //boxing : converting value type into reference type
            int anothernum = (int)obj; //unboxing : converting reference type into value type

            Console.WriteLine("type of num : " + num.GetType());
            Console.WriteLine("type of obj : " + obj.GetType());

            Console.ReadKey();
        }
    }
}
