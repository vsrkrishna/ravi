﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitlyTypeLocalVarDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = ".NET";
            object o = s;

            var str = ".NET";

            //var num;    //Error : Implicitly Local variable must be initialized
            //var val = null; //Error : Cannot assign null to an implicitly Local Variable
            var val = ".NET";
            val = null;

            //var arr = { 1, 2, 3, 5 };   //Error : Cannot initlialize implicitly typed variable with an array initializer

            var num = 34;
            //num = "Batch";      //Cannot convert string to int

        }
    }
}
