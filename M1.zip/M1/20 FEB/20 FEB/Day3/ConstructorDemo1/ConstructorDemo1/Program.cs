﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.Display();

            emp = new Employee(10, "Robert", 30000);
            emp.Display();

            Console.ReadKey();
        }
    }
}
