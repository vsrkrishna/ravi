﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibrary;

namespace MathApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();

            int num1 = 344;
            int num2 = 78;

            Calculate.Add(num1, num2);
            cal.Subtract(num1, num2);
            Calculate.Multiply(num1, num2);
            cal.Divide(num1, num2);

            Console.ReadKey();
        }
    }
}
