﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodParameterDemo
{
    class Program
    {
        public static void Swap(int num1, int num2)
        {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        public void SwapByRef(ref int num1, ref int num2)
        {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        public void CircleFunc(int radius, out double area, out double circum)
        {
            area = 3.14 * radius * radius;
            circum = 2 * 3.14 * radius;
        }

        public int Addition(params int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];
            }

            return sum;
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            int num1 = 34;
            int num2 = 78;

            Console.WriteLine("**********************************Pass By Value**********************************");
            Console.WriteLine("Before Swapping");
            Console.WriteLine($"Number 1 : {num1}");
            Console.WriteLine($"Number 2 : {num2}");
            Swap(num1, num2);
            Console.WriteLine("After Swapping");
            Console.WriteLine($"Number 1 : {num1}");
            Console.WriteLine($"Number 2 : {num2}");

            Console.WriteLine("\n\n**********************************Pass By Reference**********************************");
            Console.WriteLine("Before Swapping");
            Console.WriteLine($"Number 1 : {num1}");
            Console.WriteLine($"Number 2 : {num2}");
            p.SwapByRef(ref num1, ref num2);
            Console.WriteLine("After Swapping");
            Console.WriteLine($"Number 1 : {num1}");
            Console.WriteLine($"Number 2 : {num2}");

            Console.WriteLine("\n\n**********************************Pass By Out**********************************");
            Console.Write("Enter Radius : ");
            int radius = Convert.ToInt32(Console.ReadLine());
            double area, circum;
            p.CircleFunc(radius, out area, out circum);

            Console.WriteLine($"Area of Circle is : {area}");
            Console.WriteLine($"Circumference of Circle is : {circum}");

            Console.WriteLine("\n\n**********************************Pass By Params**********************************");
            Console.WriteLine(p.Addition(10, 20));
            Console.WriteLine(p.Addition(10, 20, 30, 40));
            Console.WriteLine(p.Addition(10, 20, 30, 40, 50, 60));

            Console.ReadKey();
        }
    }
}
