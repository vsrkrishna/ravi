﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo1
{
    class Employee : IPrint
    {
        public void Display()
        {
            Console.WriteLine("Employee Display Method from IPrint Interface");
        }

        public void Print()
        {
            Console.WriteLine("Employee Print Method from IPrint Interface");
        }
    }
}
