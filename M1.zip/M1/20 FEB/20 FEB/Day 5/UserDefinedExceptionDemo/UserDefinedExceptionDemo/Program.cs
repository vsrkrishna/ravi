﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedExceptionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();

            try
            {
                Console.Write("Enter Employee ID : ");
                emp.ID = Convert.ToInt32(Console.ReadLine());
                if (emp.ID < 100000 || emp.ID > 999999)
                {
                    throw new EmployeeException("Employee ID should be 6 digits long");
                }

                Console.Write("Enter Employee Name : ");
                emp.Name = Console.ReadLine();
                if (emp.Name == String.Empty)
                {
                    throw new EmployeeException("Employee Name should be provided");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
