﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HidingMemberDemo
{
    class Manager : Employee
    {
        public new void Show()
        {
            Console.WriteLine("Manager Show Method");
        }

        public void Display()
        {
            Console.WriteLine("Manager Display Method");
        }
    }
}
