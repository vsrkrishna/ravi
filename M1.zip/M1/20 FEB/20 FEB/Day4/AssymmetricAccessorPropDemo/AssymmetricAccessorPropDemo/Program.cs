﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssymmetricAccessorPropDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmpID = 101;
            emp.EmpName = "Robert";
            emp.Salary = 45767;

            Console.WriteLine($"Employee ID : {emp.EmpID}");
            Console.WriteLine($"Employee Name : {emp.EmpName}");
            Console.WriteLine($"Salary : {emp.Salary}");

            Console.ReadKey();
        }
    }
}
