﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoImplementedPropertyDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();

            Console.Write("Enter Employee ID : ");
            emp.EmpID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Employee Name : ");
            emp.EmpName = Console.ReadLine();

            Console.Write("Enter Salary : ");
            emp.Salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Employee ID : {emp.EmpID}");
            Console.WriteLine($"Employee Name : {emp.EmpName}");
            Console.WriteLine($"Salary : {emp.Salary}");

            Console.ReadKey();
        }
    }
}
