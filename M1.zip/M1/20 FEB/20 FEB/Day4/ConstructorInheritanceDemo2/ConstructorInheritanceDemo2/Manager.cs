﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritanceDemo2
{
    class Manager :Employee
    {
        public double Incentives { get; set; }

        public Manager(int id, string name, double sal, double ince) : base(id, name, sal)
        {
            Incentives = ince;
        }
    }
}
