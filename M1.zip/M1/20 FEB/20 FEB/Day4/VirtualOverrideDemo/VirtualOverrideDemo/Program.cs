﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(20000);
            Console.WriteLine($"Employee Salary after bonus : {emp.CalculateSalary(1000)}");

            SalesPerson sale = new SalesPerson(20000, 125);
            Console.WriteLine($"SalesPerson Salary after bonus : {sale.CalculateSalary(1000)}");

            Employee empSale = new SalesPerson(30000, 125);
            Console.WriteLine($"SalesPerson Salary after bonus : {empSale.CalculateSalary(1000)}");

            Console.ReadKey();
        }
    }
}
