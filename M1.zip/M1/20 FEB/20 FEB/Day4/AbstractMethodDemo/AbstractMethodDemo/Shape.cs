﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractMethodDemo
{
    abstract class Shape
    {
        public abstract void Draw();

        public virtual void Display()
        {
            Console.WriteLine("Shape class Display method");
        }
    }
}
