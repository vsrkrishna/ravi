﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Shape s = new Shape();  //Cannot created object of abstract class
            Circle c = new Circle();
            c.Draw();
            Console.WriteLine();

            Shape s = new Circle();
            s.Draw();

            Console.ReadKey();
        }
    }
}
