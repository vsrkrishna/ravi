﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;//using IO 
using System.Runtime.Serialization.Formatters.Binary;//using Binary Serialization

namespace Q2_File_Serialization_Deserilization
{
    /// <summary>
    /// Employee ID : 
    /// Employee Name :
    /// Date of Creation : 8-Mar-2019
    /// Description : SAVING TO THE FILE USING SERIALIZATION
    /// Description : RETRIVING FROM THE FILE USING DESERIALIZATION
    /// </summary>
    class Program
    {

        static void Main(string[] args)
        {
            //SAVING TO THE FILE USING SERIALIZATION

            Customer cus = new Customer() {Name = "Robert", Type="Saving Account",Balance = 30000.00 };//Using Files
            FileStream fs = new FileStream("Customer.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, cus);
            fs.Close();

            // RETRIVING FROM THE FILE USING DESERIALIZATION

            fs = new FileStream("Customer.txt", FileMode.Open, FileAccess.Read);//Using Files
            Customer newcus = (Customer)bin.Deserialize(fs);
            fs.Close();

            Console.WriteLine($"Employee ID : {newcus.Name}");
            Console.WriteLine($"Employee Name : {newcus.Type}");
            Console.WriteLine($"Employee Salary : {newcus.Balance}");


            Console.ReadKey();

        }
    }
}
