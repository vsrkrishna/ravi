﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1Calculator
{

    /// <summary>
    /// Employee ID : 174790
    /// Employee Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description : CALCULATOR METHODS FOR DIVISION AND MODULUS
    /// </summary>
    class Calculate
    {
        public void Division(int num1, int num2)
        {
            Console.WriteLine($"{num1} / {num2} => {(num1 / num2)}");
        }
        public void Modulus(int num1, int num2)
        {
            Console.WriteLine($"{num1} % {num2} => {(num1 % num2)}");
        }

    }
}
