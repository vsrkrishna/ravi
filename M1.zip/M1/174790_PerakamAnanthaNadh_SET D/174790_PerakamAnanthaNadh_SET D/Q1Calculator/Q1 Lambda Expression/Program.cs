﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_Lambda_Expression
{
    class Program
    {
        /// <summary>
        /// Employee ID : 174790
        /// Employee Name :PERAKAM ANANTHANADH
        /// Date of Creation : 12-Mar-2019
        /// Description : USING  LAMBDA EXPRESSIONS
        /// </summary>
        public delegate void LambdaDelwithParam(int num1, int num2);

        static void Main(string[] args)
        {
           //Using Lambda Expressions by Division

            LambdaDelwithParam Division= (num1, num2) => Console.WriteLine($"{num1}/{num2}=>{(num1 / num2)}");
            Division(50, 2);

            //Using Lambda Expressions by Modulus
            LambdaDelwithParam Modulus = (num1, num2) => Console.WriteLine($"{num1}%{num2}=>{(num1 % num2)}");
            Modulus(29, 3);

            Console.ReadKey();
        }
    }
}
