﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shape;

namespace Lab4._2Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape.Shape s= new Triangle(); 
            s.WhoamI();
            Shape.Shape s1 = new Circle();
            s1.WhoamI();
            Console.ReadKey();
        }  
    
    }
}
