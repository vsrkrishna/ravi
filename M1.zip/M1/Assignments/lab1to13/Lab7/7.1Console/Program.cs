﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact;

namespace _7._1Console
{
    class Program
    {
        static List<Contact.Contact> contact = new List<Contact.Contact>();
        static void Main(string[] args)
        {
            PrintMenu();
            Console.ReadLine();
        }
        static void PrintMenu()
        {
            string choice1;
            do
            {
                Console.WriteLine("select ur choice:");
                Console.WriteLine("1. Add Contact\n2. Display Contact\n3. Edit Contact\n4. Show all contacts");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddContact();
                        break;
                    case 2:
                        DisplayContact();
                        break;
                    case 3:
                        EditContact();
                        break;
                    case 4:
                        ListAllContacts();
                        break;
                }
                Console.WriteLine("Do you want to continue(y/n)?");
                choice1 = Console.ReadLine();
            } while (choice1 == "y");
            Console.ReadLine();
        }
        static void AddContact()
        {
            Contact.Contact con = new Contact.Contact();
            Console.WriteLine("enter contact id:");
            con.ContactNo = int.Parse(Console.ReadLine());
            Console.WriteLine("enter contact name: ");
            con.ContactName = Console.ReadLine();
            Console.WriteLine("enter cell no: ");
            con.CellNo = Console.ReadLine();
            contact.Add(con);
        }
        static void DisplayContact()
        {
            List<Contact.Contact> cont = contact;
            Console.WriteLine("no   name   cell");
            foreach (Contact.Contact c in cont)
            {
                Console.WriteLine(c.ContactNo + " " + c.ContactName + " " + c.CellNo);
            }
        }
        static void EditContact()
        {
            List<Contact.Contact> contt = contact;
            int updateID;
            Console.WriteLine("enter contact id:");
            updateID = int.Parse(Console.ReadLine());
            for (int i = 0; i < contt.Count; i++)
            {
                Contact.Contact cont = contact[i];
                if (updateID == cont.ContactNo)
                {
                    Console.WriteLine("enter name:");
                    cont.ContactName = Console.ReadLine();
                    Console.WriteLine("enter cell no:");
                    cont.CellNo = Console.ReadLine();
                }
            }
        }
        static void ListAllContacts()
        {
            List<Contact.Contact> cont = contact;
            Console.WriteLine("no   name   cell");
            foreach (Contact.Contact c in cont)
            {
                Console.WriteLine(c.ContactNo + " " + c.ContactName + " " + c.CellNo);
            }
        }
    }
}
