﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SupplierTest;

namespace Lab3._4Supplier_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            SupplierTest.SupplierTest s = new SupplierTest.SupplierTest();
            s.AcceptDetails();
            s.Display();
            Console.ReadLine();
        }
    }
}
