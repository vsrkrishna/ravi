﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._2_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            AcceptDetails();
            Console.ReadLine();
        }
        public static void AcceptDetails()
        {
            ProductMock product = new ProductMock();
            try
            {
                Console.WriteLine("product ID:");
                product.ProID = int.Parse(Console.ReadLine());
                Console.WriteLine("product name: ");
                product.ProName = Console.ReadLine();
                Console.WriteLine("price: ");
                product.Price = double.Parse(Console.ReadLine());
                Console.WriteLine("productid: " + product.ProID);
                Console.WriteLine("product name: " + product.ProName);
                Console.WriteLine("proce: " + product.Price);            
                if (product.ProID <= 0)
                {
                    throw new DataEntryException("Product ID must be greater than zero");
                }

                if (product.ProName == string.Empty)

                {
                    throw new DataEntryException("Product Name cannot be left blank");
                }

                if (product.Price <= 0)

                {
                    throw new DataEntryException("price must be greater than zero");
                }

            }

            catch (DataEntryException de)
            {
                Console.WriteLine(de.Message);
            }
        }
    }

    public class ProductMock

    {

        private int productId;

        private string productName;

        private double price;

        public int ProID { get { return productId; } set { productId = value; } }

        public string ProName { get { return productName; } set { productName = value; } }

        public double Price { get { return price; } set { price = value; } }

        public ProductMock() { }

        public ProductMock(int pID, string pName, double Pri)

        {

            productId = pID;

            productName = pName;

            price = Pri;

        }

    }

    public class DataEntryException : ApplicationException

    {

        public DataEntryException() : base() { }




        public DataEntryException(string message) : base(message) { }




        public DataEntryException(string message, Exception innerException) : base(message, innerException) { }




    }

}
    

