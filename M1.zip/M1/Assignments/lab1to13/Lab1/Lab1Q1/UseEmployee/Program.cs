﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace UseEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
             Employee.Employee[] emp  = GetEmployeeData();
           
            DisplayEmployeeDetails(emp);
            
            Console.ReadLine();
        }
        private static Employee.Employee[] GetEmployeeData()
        {   

            Employee.Employee[] emp = new Employee.Employee[10];
            for (int i = 0; i < 10; i++)
            {
                emp[i] = new Employee.Employee();
                Employee.Employee e = new Employee.Employee();

                Console.WriteLine("----------Employee Management--------");
                Console.WriteLine("Enter the details for Employee :{0}", i + 1);
                Console.WriteLine("Enter the value of Eid");
                e.SetID(Int32.Parse(Console.ReadLine()));
                Console.WriteLine("Enter the value of Ename");
                e.SetName(Console.ReadLine());
                Console.WriteLine("Enter the value of city");
                e.SetCity(Console.ReadLine());
                Console.WriteLine("Enter the value of EAdd");
                e.SetAddress(Console.ReadLine());
                Console.WriteLine("Enter the value of dept");
                e.SetDepartment(Console.ReadLine());
                Console.WriteLine("Enter the value of sal");
                e.SetSalary(Int32.Parse(Console.ReadLine()));
               
           }
            return emp;
            
        }
        //Displaying Employee Information
        private static void DisplayEmployeeDetails(Employee.Employee[] emp)
        {
            for (int i = 0; i < 10; i++)
                Console.WriteLine(@"ID : {0}\nNAME :{1}\n 
                                    Address :{2}\n
                                    City :{3}\n 
                                    Department :{4}\n
                                    Salary :{5} ", emp[i].GetID(), emp[i].GetName(), emp[i].GetAddress(),
                                                   emp[i].GetCity(), emp[i].GetDepartment(), emp[i].GetSalary());

        }


    }
    
}
