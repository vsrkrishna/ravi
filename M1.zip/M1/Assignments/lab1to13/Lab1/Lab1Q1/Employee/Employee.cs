﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employee
    {
        public int Eid;
        public string EName;
        public string Eadd;
        public string city;
        public string Dept;
        public double Sal;

        public int GetID()
        {
            return Eid;
        }
        public void SetID(int Eid)
        {
            this.Eid = Eid;
        }

        public string GetName()
        {
            return EName;
        }
        public void SetName(string EName)
        {
            this.EName = EName;
        }
        public string GetAddress()
        {
            return Eadd;
        }
        public void SetAddress(string Eadd)
        {
            this.Eadd = Eadd;
        }
        public string GetCity()
        {
            return city;
        }
        public void SetCity(string city)
        {
            this.city = city;
        }
        public string GetDepartment()
        {
            return Dept;
        }
        public void SetDepartment(string Dept)
        {
            this.Dept = Dept;
        }
        public double GetSalary()
        {
            return Sal;
        }
        public void SetSalary(double Sal)
        {
            this.Sal = Sal;
        }


    }
}
