﻿using System;

namespace StudentDetails
{
    public class StudentDetails
    {
        public int rollNo;
        public string sName;
        public int age;
        public char gender;
        public DateTime DateOfBirth;
        public string Add;
        public double Percentage;

        public int GetRno()
        {
            return rollNo;
        }
        public void SetRno(int rollNo)
        {
            this.rollNo = rollNo;
        }
        public string GetName()
        {
            return sName;

        }
        public void SetName(string sName)
        {
            this.sName = sName;

        }
        public int GetAge()
        {
            return age;

        }
        public void SetAge(int age)
        {
            this.age = age;

        }
        public char GetGender()
        {
            return gender;

        }
        public void SetGender(char gender)
        {
            this.gender = gender;

        }
        public DateTime GetDOB()
        {
            return DateOfBirth;

        }
        public void SetDOB(DateTime DateOfBirth)
        {
            this.DateOfBirth = DateOfBirth;

        }
        public string GetAdd()
        {
            return Add;

        }
        public void SetAdd(string Add)
        {
            this.Add = Add;

        }
        public double GetPercentage()
        {
            return Percentage;

        }
        public void SetPercentage(double Percentage)
        {
            this.Percentage = Percentage;

        }
    }
}
