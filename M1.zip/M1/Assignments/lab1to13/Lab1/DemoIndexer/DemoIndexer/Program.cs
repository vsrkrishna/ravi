﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoIndexer
{
    class MyClass
    {
        private string[] myArray = new string[10];
        //Indexer declaration:
        public string this[int index]
        {
            get
            {
                return myArray[index];
            }
            set
            {
                myArray[index] = value;

            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyClass s = new MyClass();
            //Using Indexer to initialize the elements #1 and #2
            s[1] = "Tom";
            s[2] = "Edison";
            for(int i =0; i < 5; i++)
            {
                Console.WriteLine("Element #{0}={1} ", i,s[i]);
                Console.ReadLine();
            }
        }
    }
}
