﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****OPERATIONS**** ");
            Console.WriteLine("1");
            Console.WriteLine("2");
            Console.WriteLine("3");
            Console.WriteLine("4");
            Console.WriteLine("5");
            Console.WriteLine("Enter User Choice");
            int UserChoice = Int32.Parse(Console.ReadLine());
            switch (UserChoice)
            {
                case 1:
                    Console.WriteLine("you have enterd the Choice 1");
                    break;
                case 2:
                    Console.WriteLine("You have enterd the Choice 2");
                    break;
                case 3:
                    Console.WriteLine("you have enterd the Choice 3");
                    break;
                case 4:
                    Console.WriteLine("you have enterd the Choice 4");
                    break;
                case 5:
                    Console.WriteLine("you have enterd the choice 5");
                    break;
                default:
                    Console.WriteLine("Entered choice is Invalid");
                    break;
                   
            }
            Console.ReadLine();
        }
    }
}
