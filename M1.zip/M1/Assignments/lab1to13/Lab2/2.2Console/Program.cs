﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2._2Console
{
    class Program
    {
        public string title { get; set; }

        public string Author { get; set; }

        public string publisher { get; set; }

        public string price { get; set; }
        static void Main(string[] args)
        {
            MultiDArray();

        }

        static void MultiDArray()
        {
            Program bookobj = new Program();
            Console.WriteLine("---> Enter the book Details <---");
            string[,] len = new string[2, 4];
            for (int i = 0; i < len.GetLength(0); i++)
            {
               Console.WriteLine("Enter the book title");
                len[i, 0] = Console.ReadLine();
                Console.WriteLine("Enter the book author");
                len[i, 1] = Console.ReadLine();
                Console.WriteLine("Enter the book publisher");
                len[i, 2] = Console.ReadLine();
                Console.WriteLine("Enter the book price");
                len[i, 3] = Console.ReadLine();
            }
            Console.WriteLine("---> Enter the data from the user <---");
            for (int i = 0; i < len.GetLength(0); i++)
            {
                Console.WriteLine("Book name:{0} Book Author:{1} Book Publisher:{2} Book price:{3}", len[i, 0].ToString(), len[i, 1].ToString(), len[i, 2].ToString(), len[i, 3].ToString());
                Console.ReadLine();
            }
        }
    }
}
