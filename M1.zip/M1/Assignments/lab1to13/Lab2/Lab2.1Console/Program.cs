﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqCube;

namespace Lab2._1Console
{
    class Program
    {
        static void Main(string[] args)
        {
            int Number;
            Console.WriteLine("Enter the number; ");
            Number = Convert.ToInt32(Console.ReadLine());
            int UserChoice;
            Console.WriteLine("Enter 1 for Square 2 for Cube");
            UserChoice = Convert.ToInt32(Console.ReadLine());
            switch (UserChoice)
            {
                //Square
                case 1:
                    Class1 obj = new SqCube.Class1();
                    int sqr = Class1.Square(Number);
                    Console.WriteLine("Square of the number is :" + sqr);
                    break;
                    //Cube
                case 2:
                    Class1 obj1 = new SqCube.Class1();
                    int cube = Class1.Cube(Number);
                    Console.WriteLine("Cube of the number is :" + cube);
                    break;
            }
            Console.ReadLine();
        }
    }
}
