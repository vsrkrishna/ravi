﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FB.Entites
{
    public class Flightbooking
    { 
        public int TicketId { get; set; }
        public string CustomerName { get; set; }
       public double price { get; set; }
       
    }
}
