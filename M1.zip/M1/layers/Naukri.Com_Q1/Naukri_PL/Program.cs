﻿using Applicant_BAL;
using Naukri_Entities;
using Naukri_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri_PL
{
    class Program
    {
        public static void AddApplicant()
        {
            try
            {
                Applicant applicant = new Applicant();
                Console.WriteLine("Enter Applicant Name:");
                applicant.Name = Console.ReadLine();
                Console.WriteLine("Enter Applicant Qualification:");
                applicant.Qualification = Console.ReadLine();
                Console.WriteLine("Enter Applicant DOB:");
                applicant.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Applicant Mobile No:");
                applicant.MobileNo = Console.ReadLine();
                Console.WriteLine("Enter Applicant City:");
                applicant.City = Console.ReadLine();


                bool ApplicantAdded = ApplicantBAL.AddApplicantBAL(applicant);
                if (ApplicantAdded == true)
                {
                    Console.WriteLine("Student Added Successfully");
                }
                else
                {
                    throw new ApplicantNotFoundException("Student not added");
                }
                ApplicantBAL.SerializeData();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchApplicant()
        {


            string qual;
            Applicant searchApplicant;
            try
            {
                Console.WriteLine("Enter Applicacant Qualification to be Searched:");
                qual = Console.ReadLine();

                searchApplicant = ApplicantBAL.SearchApplicantBAL(qual);
                if (searchApplicant != null)
                {
                    Console.WriteLine("Applivcant Qualification:" + searchApplicant.Qualification);
                    Console.WriteLine("Applicant Name:" + searchApplicant.Name);
                    Console.WriteLine("Applicant Mobile no:" + searchApplicant.MobileNo);
                    Console.WriteLine("Applicant DOB:" + searchApplicant.DOB);
                    Console.WriteLine("Applicant City:" + searchApplicant.City);
                }
                else
                {
                    throw new ApplicantNotFoundException("Student not Found");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("**********Naukri.Com**********");
            Console.WriteLine("1.Add Applicant\n");
            Console.WriteLine("2.Search Applicant\n");
        }

        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                bool validChoice;
                Console.WriteLine("Enter your Choice Please:");
                validChoice = Int32.TryParse(Console.ReadLine(), out choice);

                if (!validChoice)
                    Console.WriteLine("Enter the choice from 1-2");
                else
                {
                    switch (choice)
                    {
                        case 1:
                            AddApplicant();
                            break;
                        case 2:
                            SearchApplicant();
                            break;              
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }
            } while (choice != 0);
            Console.ReadKey();

        }
    }
}
