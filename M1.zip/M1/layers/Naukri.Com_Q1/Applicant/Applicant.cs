﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri_Entities
{
    [Serializable]
    public class Applicant
    {
        public string Name { get; set; }
        public string Qualification { get; set; }
        public string MobileNo { get; set; }
        public string City { get; set; }
        public DateTime DOB { get; set; }

        public Applicant()
        {

        }
        public Applicant(string Name, string Qualification, string MobileNo, string City, DateTime DOB)
        {
            this.Name = Name;
            this.Qualification = Qualification;
            this.MobileNo = MobileNo;
            this.City = City;
            this.DOB = DOB;
        }
    }
}
