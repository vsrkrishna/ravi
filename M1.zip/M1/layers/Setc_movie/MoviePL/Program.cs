﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using MovieException;
using MovieBL;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace MoviePL
{
    class Program
    {
        public static void AddMovie()
        {
            try
            {
                Movie mv = new Movie();
                Console.Write("Enter Movie Title : ");
                mv.Movietitle = Console.ReadLine();
                Console.Write("Enter Movie Release Date : ");
                mv.MovieRelease = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter publisher : ");
                mv.Publisher = Console.ReadLine();
                Console.Write("Enter  acting Rating : ");
                mv.Acting = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter  music Rating : ");
                mv.Music = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter  cinematography Rating : ");
                mv.Cinematogory = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter  duration Rating : ");
                mv.Duration = Convert.ToInt32(Console.ReadLine());

                bool mvAdded = MovieValidations.AddMovie(mv);

                if (mvAdded)
                {
                    Console.WriteLine("Movie added successfully");
                }
                else
                {
                    throw new MoviesException1("Movie not added");
                }
            }
            catch (MoviesException1 ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeMovie()
        {
            try
            {
                bool mvSerialized = MovieValidations.SerializeMovie();

                if (mvSerialized)
                {
                    Console.WriteLine("Movie data serialized");
                }
                else
                {
                    throw new MoviesException1("Movie data not serialized");
                }
            }
            catch (MoviesException1 ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeMovie()
        {
            try
            {
                List<Movie> mvList = MovieValidations.DeserializeMovie();

                if (mvList != null || mvList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    // Console.WriteLine("MovieTittle    Employee Name   Phone Number   Date of Birth   Date of Joining   City");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var mv in mvList)
                    {
                        Console.WriteLine($"{mv.Movietitle}\t\t{mv.MovieRelease}\t{mv.Publisher}\t{mv.Acting}\t{mv.Music}\t{mv.Cinematogory}\t{mv.Duration}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new MoviesException1("Movie data not available after deserialization");
                }
            }
            catch (MoviesException1 ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2 SerilizationMovie");
            Console.WriteLine("3 DeserilizationMovie");

        }
        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddMovie();
                        break;
                    case 2:
                        SerializeMovie();
                        break;
                    case 3:
                        DeserializeMovie();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
            }
            while (choice != 4);

            Console.ReadKey();
        }
    } }

