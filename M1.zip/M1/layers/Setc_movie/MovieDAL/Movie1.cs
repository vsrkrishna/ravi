﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using MovieException;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace MovieDAL
{
    public class Movie1
    {
        static List<Movie> mvList= new List<Movie>();

        //To insert the employee record in employee list
        public static bool AddMovie(Movie mv)
        {
            bool mvAdded = false;

            try
            {
                //Adding employee object into employee list
                mvList.Add(mv);
                mvAdded = true;
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mvAdded;
        }
        //To Serialize employee list
        public static bool SerializeMovie()
        {
            bool empSerialized = false;


            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, mvList);
                fs.Close();
                empSerialized = true;
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        //To deserialize employee List
        public static List<Movie> DeserializeMovie()
        {
            List<Movie> empDesList = null;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                empDesList = (List<Movie>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDesList;
        }
    }


}

