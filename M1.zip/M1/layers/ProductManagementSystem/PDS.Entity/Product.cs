﻿using System;

namespace PDS.Entity
{
    [Serializable]
    public class Product
    {

            //Get or set Product ID
            public  string ProductID{ get; set; }


            //Get or set Product Name
            public string ProductName { get; set; }

            //Get or set Phone Number
            public int price { get; set; }

            //Get or set Date of Birth
            public DateTime DOB { get; set; }

            //Get or set Date of Joining
            public DateTime MFD { get; set; }

            
        }
    }



