﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDS.Exception
{
    public class ProductExceptions: ApplicationException
    {
       
            //Default Constructor
            public ProductExceptions() : base()
            { }

            //Parameterized Constructor to initialize Message property
            public ProductExceptions(string message) : base(message)
            { }
        }
}
