﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDS.Entity;
using PDS.Exception;
using PDS.BL;
namespace PDS.PL
{
    class Program
    {
        

            public static void AddProduct()
            {
                try
                {
                    Product pdt = new Product();
                    Console.Write("Enter Product ID : ");
                    pdt.ProductID = Console.ReadLine();
                    Console.Write("Enter Product Name : ");
                    pdt.ProductName = Console.ReadLine();
                    Console.Write("Enter Price : ");
                    pdt.price = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Date of Buy : ");
                    pdt.DOB = Convert.ToDateTime(Console.ReadLine());
                    Console.Write("Enter MANUFACTURE date: ");
                    pdt.MFD = Convert.ToDateTime(Console.ReadLine());


                    bool pdtAdded = ProductValidations.AddProduct(pdt);

                    if (pdtAdded)
                    {
                        Console.WriteLine("Product added successfully");
                    }
                    else
                    {
                        throw new ProductExceptions("Product not added");
                    }

                }
                catch (ProductExceptions ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            /*   public static void UpdateProduct()
               {
                   try
                   {
                       Product pdt = new Product();
                       Console.Write("Enter Product ID to be updated : ");
                       pdt.ProductID = Convert.ToInt32(Console.ReadLine());
                       Console.Write("Enter updated Product Name : ");
                       pdt.ProductName = Console.ReadLine();
                       Console.Write("Enter updated Phone Number : ");
                       pdt.PhoneNo = Console.ReadLine();
                       Console.Write("Enter updated Date of Birth : ");
                       pdt.DOB = Convert.ToDateTime(Console.ReadLine());
                       Console.Write("Enter updated Date of Joining : ");
                       pdt.DOJ = Convert.ToDateTime(Console.ReadLine());
                       Console.Write("Enter updated City : ");
                       pdt.City = Console.ReadLine();

                       bool pdtUpdated = ProductValidations.UpdateProduct(pdt);

                       if (pdtUpdated)
                       {
                           Console.WriteLine("Product updated successfully");
                       }
                       else
                       {
                           throw new ProductException("Product not updated");
                       }
                   }
                   catch (ProductException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
                   catch (SystemException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
               }

               /*public static void DeleteProduct()
               {
                   try
                   {
                       int pdtID;
                       Console.Write("Enter Product ID to be Deleted : ");
                       pdtID = Convert.ToInt32(Console.ReadLine());

                       bool pdtDeleted = ProductValidations.DeleteProduct(pdtID);

                       if (pdtDeleted)
                       {
                           Console.WriteLine("Product deleted successfully");
                       }
                       else
                       {
                           throw new ProductException("Product not deleted");
                       }
                   }
                   catch (ProductException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
                   catch (SystemException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
               }

               public static void SearchProduct()
               {
                   try
                   {
                       int pdtID;
                       Console.Write("Enter Product ID to be Searched : ");
                       pdtID = Convert.ToInt32(Console.ReadLine());

                       Product pdt = ProductValidations.SearchProduct(pdtID);

                       if (pdt != null)
                       {
                           Console.WriteLine($"Product ID : {pdt.ProductID}");
                           Console.WriteLine($"Product Name : {pdt.ProductName}");
                           Console.WriteLine($"Phone Number : {pdt.PhoneNo}");
                           Console.WriteLine($"Date of Birth : {pdt.DOB}");
                           Console.WriteLine($"Date of Joining : {pdt.DOJ}");
                           Console.WriteLine($"City : {pdt.City}");
                       }
                       else
                       {
                           throw new ProductException("Product not found");
                       }
                   }
                   catch (ProductException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
                   catch (SystemException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
               }

               public static void RetrieveProduct()
               {
                   try
                   {
                       List<Product> pdtList = ProductValidations.RetrieveProducts();

                       if (pdtList != null || pdtList.Count > 0)
                       {
                           Console.WriteLine("------------------------------------------------------------------------------------");
                           Console.WriteLine("Product ID    Product Name   Phone Number   Date of Birth   Date of Joining   City");
                           Console.WriteLine("------------------------------------------------------------------------------------");
                           foreach (var pdt in pdtList)
                           {
                               Console.WriteLine($"{pdt.ProductID}\t\t{pdt.ProductName}\t{pdt.PhoneNo}\t{pdt.DOB}\t{pdt.DOJ}\t{pdt.City}");
                           }
                           Console.WriteLine("------------------------------------------------------------------------------------");
                       }
                       else
                       {
                           throw new ProductException("Product data not available");
                       }
                   }
                   catch (ProductException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
                   catch (SystemException ex)
                   {
                       Console.WriteLine(ex.Message);
                   }
               }*/
        
            public static void SerializeProduct()
            {
                try
                {
                    bool pdtSerialized = ProductValidations.SerializeProduct();

                    if (pdtSerialized)
                    {
                        Console.WriteLine("Product data serialized");
                    }
                    else
                    {
                        throw new ProductExceptions("Product data not serialized");
                    }
                }
                catch (ProductExceptions ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static void DeserializeProduct()
            {
                try
                {
                    List<Product> pdtList = ProductValidations.Deserializeproduct();

                    if (pdtList != null || pdtList.Count > 0)
                    {
                        Console.WriteLine("------------------------------------------------------------------------------------");
                        Console.WriteLine("Product ID    Product Name   price   Date of manufacture   Date of buy   ");
                        Console.WriteLine("------------------------------------------------------------------------------------");
                        foreach (var pdt in pdtList)
                        {
                            Console.WriteLine($"{pdt.ProductID}\t\t{pdt.ProductName}\t{pdt.price}\t{pdt.DOB}\t{pdt.MFD}\t");
                        }
                        Console.WriteLine("------------------------------------------------------------------------------------");
                    }
                    else
                    {
                        throw new ProductExceptions("Product data not available after deserialization");
                    }
                }
                catch (ProductExceptions ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        public static void RetrieveProduct()
        {
            try
            {
                List<Product> pdtList = ProductValidations.RetrieveProduct();

                if (pdtList != null || pdtList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("ProductID    ProductName   price   Date of Buy   Manufacture Date");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var p in pdtList)
                    {
                        Console.WriteLine($"{p.ProductID}\t\t{p.ProductName}\t{p.price}\t{p.DOB}\t{p.MFD}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new ProductExceptions("product data not available");
                }
            }
            catch (ProductExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchProduct()
        {
            try
            {
                string proid;
                Console.Write("Enter Product ID to be Searched : ");
                proid = Console.ReadLine();

                Product p = ProductValidations.SearchProduct(proid);

                if (p != null)
                {
                    Console.WriteLine($"Employee ID : {p.ProductID}");
                    Console.WriteLine($"Employee Name : {p.ProductName}");
                    Console.WriteLine($"Phone Number : {p.price}");
                    Console.WriteLine($"Date of Birth : {p.DOB}");
                    Console.WriteLine($"Date of Joining : {p.MFD}");
                    
                }
                else
                {
                    throw new ProductExceptions("Product not found");
                }
            }
            catch (ProductExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
            public static void PrintMenu()
            {
                Console.WriteLine("***********************");
                Console.WriteLine("1. Add Product");

                Console.WriteLine("4. Display Product");
                Console.WriteLine("2. Serialize Product");
                Console.WriteLine("3. Deserialize Product");
                Console.WriteLine("5. search Product");
                Console.WriteLine("6. Exit");
                Console.WriteLine("***********************");
            }
        
        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddProduct();
                        break;

                    case 2: SerializeProduct();
                        break;
                    case 3:
                        DeserializeProduct();

                        break;
                    case 4:
                        RetrieveProduct();
                        break;
                    case 5:
                        SearchProduct();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
            } while (choice != 6);

            Console.ReadKey();
        }

        
    }
}


    

