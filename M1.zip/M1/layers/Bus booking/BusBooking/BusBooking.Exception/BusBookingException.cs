﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusBooking.Exception
{
    public class BusBookingException :ApplicationException
    {
        public BusBookingException()
           : base()
        {
        }

        public BusBookingException(string message)
            : base(message)
        {
        }
    }
}
