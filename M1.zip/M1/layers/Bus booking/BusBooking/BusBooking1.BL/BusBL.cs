﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusBooking;
using BusBooking.Exception;
using Bus.DAL;
//using System.Data.SqlClient;
//using System.Configuration;
namespace BusBooking1.BL
{
    public class BusBL
    {
        public static bool ValidateBus(Busb bbk)
        {
            bool result = true;
            StringBuilder sb = new StringBuilder();

            if (bbk.BusName== string.Empty)
            {
                result = false;
                sb.Append("BookName cannot be blank");
            }

            if (bbk.BoardingDate == .Empty)
            {
                result = false;
                sb.Append("Authot Name Cannot be blank");
            }
            if (bbk.price <= 0)
            {
                result = false;
                sb.Append("Price cannot be negative or zero");
            }

            if (result == false)
            {
                throw new BusBookingException(sb.ToString());
            }
            return result;
        }

        public static bool AddBusBL(Busb bk)
        {
            bool busBookedaddded = false;
            try
            {
                if (ValidateBus(bk))
                {
                    BusDal obj = new BusDal();
                    busBookedaddded = obj.AddBusDetails(bk);
                }
            }
            catch (Exception ex)
            {
                throw new BusBookingException(ex.Message);
            }

            return busBookedaddded;
        }

        public static List<Busb> GetAllBookBL()
        {
            List<Busb> busllist = null;

            try
            {
                BusDal bmsdal = new BusDal();
                busllist = bmsdal.GetAllBusDetails();
            }
            catch (BusBookingException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return busllist;
        }

    }
}
