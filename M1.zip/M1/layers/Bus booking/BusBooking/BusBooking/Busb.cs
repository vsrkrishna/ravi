﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusBooking
{
    public class Busb
    {
        public int BusNo { get; set; }
        public string BusName { get; set; }
        public DateTime BoardingDate { get; set; }
        public DateTime DesinationDate{ get; set; }
        public int Price { get; set; }


    }
}
