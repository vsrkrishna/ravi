﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSException
{
    public class EMSException1:ApplicationException
    {
        //Default Constructor
        public EMSException1() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public EMSException1(string message) : base(message)
        { }
    }
}
