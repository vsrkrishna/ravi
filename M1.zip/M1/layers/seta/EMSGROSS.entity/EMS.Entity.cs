﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSGROSS.entity
{
    [Serializable]
    public class Class1
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Pf { get; set; }
        public int Hra { get; set; }
        public int Grossslalary { get; set; }
        public int Salary { get; set; }
        public int Netsalary { get; set; }

    }
}
