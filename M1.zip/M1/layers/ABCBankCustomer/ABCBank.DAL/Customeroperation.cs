﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABCBank.Exception; //Reference to Exception Class Library
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using ABCBank;////Reference to Entity Class Library

namespace ABCBank.DAL
{
    /// <summary>
    /// Employee ID :174867
    /// Employee Name : Revati Chaudhari
    /// Date of Creation : 12-Mar-2019
    /// Description:Database operations on account Class
    /// </summary>

    public class Customeroperation
    {
        static List<Account> accList = new List<Account>();
        private static double balance;

        //To insert the Account record in Account list
        public static bool AddAccount(Account acc)
        {
            bool accAdded = false;
            

            try
            {
                //Adding Account object into Account list
                accList.Add(acc);
                accAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accAdded;
        }

        //To modify the Account data from the list
        public static bool UpdateAccount(Account acc)
        {
            bool accUpdated = false;

            try
            {
                for (int i = 0; i < accList.Count; i++)
                {
                    //Searching employee to update
                    if (accList[i].AccountNo == acc.AccountNo)
                    {
                        //Modifying employee details
                        accList[i].CustomerName = acc.CustomerName;
                        accList[i].AccountType = acc.AccountType;
                       balance= acc.GetBalance();
                        

                        accUpdated = true;
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accUpdated;
        }

        //To delete employee from employee list
        public static bool DeleteAccount(int AccountNo)
        {
            bool empDeleted = false;

            try
            {
                //Searching employee
                Account acc = accList.Find(e => e.AccountNo == AccountNo);

                if (acc != null)
                {
                    //Deleting employee from employee list
                    accList.Remove(acc);
                    empDeleted = true;
                }
                else
                {
                    throw new CustomerException("Account no " + AccountNo + " does not exist for Delete");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }



        //To retrieve all Account
        public static List<Account> RetrieveAccount()
        {
            return accList;
        }


        //To Serialize Account list
        public static bool SerializeAccount()
        {
            bool accSerialized = false;

            try
            {
                FileStream fs = new FileStream("Account.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, accList);
                fs.Close();
                accSerialized = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accSerialized;
        }

        //To deserialize account List
        public static List<Account> DeserializeAccount()
        {
            List<Account> accDesList = null;

            try
            {
                FileStream fs = new FileStream("Account.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                accDesList = (List<Account>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accDesList;
        }

    }
}
