﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCBank
{
    /// <summary>
    /// Employee ID :174867
    /// Employee Name : Revati Chaudhari
    /// Date of Creation : 12-Mar-2019
    /// Description:Entity class for Account
    /// </summary>
    [Serializable]
    
    public class Account
    {

       
        //Get or set Account No
        public int AccountNo { get; set; }
        private string customerName;
        public string CustomerName { get { return customerName; } set { customerName = value; } }
        private double balance;
        public BankAccountTypeEnum AccountType
        {
            get ;
            set ;
        }

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }

        public double GetBalance()
        {
            return balance;
        }

        public virtual bool Withdraw(double amount)
        {
            balance = balance - amount;
            return true;
        }
    }
    public enum BankAccountTypeEnum { Current = 1, Saving = 2 }
}
