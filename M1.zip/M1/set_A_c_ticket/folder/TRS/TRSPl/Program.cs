﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS;
    using TRSBL;
using TRSException;
namespace TRSPl
{
    class Program
    {

        public static void AddMovie()
        {
            try
            {
                TRSEntity mv = new TRSEntity();
                Console.Write("Enter ticket no: ");
                mv.TicketNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter booking Date : ");
                mv.BookingDate = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter source : ");
                mv.Source = Console.ReadLine();
                Console.Write("Enter  destimnation : ");
                mv.Destination = Console.ReadLine();
                Console.Write("Enter  nooftickets : ");
                mv.NoOfTickets = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter  type : ");
                mv.Type = Console.ReadLine();



                bool mvAdded = TRSValidations.AddEmployee(mv);

                if (mvAdded)
                {
                    //string ch;
                    //ch = Console.ReadLine();
                    switch (mv.Type)
                    {
                        case "sleeper":
                       // default:
                            mv.Price = 500;
                            break;
                        case "3AC":
                            mv.Price = 900;
                            break;
                        case "2AC":
                            mv.Price = 1100;
                            break;
                        case "1AC":
                            mv.Price = 1500;
                            break;

                    }
                    Console.WriteLine($"Movie added successfully" +
                        $"with ticket cost  {mv.Price}");
                }
                else
                {
                    throw new Exception1("Movie not added");
                }
            }
            catch (Exception1 ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
       
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Employee");
           // Console.WriteLine("2 SerilizationMovie");
           //Console.WriteLine("3 DeserilizationMovie");

        }
        static void Main(string[] args)
        {
            //TRSEntity mv = new TRSEntity();
            //Console.WriteLine($"price os the ticket is {mv.Price}");
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddMovie();
                        break;
                    //case 2:
                    //    SerializeMovie();
                    //    break;
                    //case 3:
                    //    DeserializeMovie();
                    //    break;
                    //case 4:
                    //    Environment.Exit(0);
                    //    break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
            }
            while (choice != 4);

            Console.ReadKey();

        }
    }
}

