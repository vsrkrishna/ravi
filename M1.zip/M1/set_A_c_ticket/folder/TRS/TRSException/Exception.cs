﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSException
{
    public class Exception1:ApplicationException
    {
        //Default Constructor
        public Exception1() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public Exception1(string message) : base(message)
        { }
    }
}
