﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS;
using TRSException;
using TRSDAL;
using System.Text.RegularExpressions;
namespace TRSBL
{
    public class TRSValidations
    {
        //To validate trsloyee details
        public static bool ValidateTRS(TRSEntity trs)
        {
            bool trsValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - trsloyee id should be 6 digit
                if (trs.TicketNo < 10000000 || trs.TicketNo > 99999999)
                {
                    trsValidated = false;
                    message.Append("ticket ID should be exactly 8 digits long\n");
                }

                //Checking - trsloyee name
                if (trs.Source == String.Empty)
                {
                    trsValidated = false;
                    message.Append("Ticket source should be provided\n");
                }
                else if (!Regex.IsMatch(trs.Source, "[A-Z][a-z]{2,}"))
                {
                    trsValidated = false;
                    message.Append("Ticket Source should start with capital alphabet and it should have minimum 3 alphabets\n");
                }
                if (trs.Destination == String.Empty)
                {
                    trsValidated = false;
                    message.Append("Ticket Source should be provided\n");
                }
                else if (!Regex.IsMatch(trs.Destination, "[A-Z][a-z]{2,}"))
                {
                    trsValidated = false;
                    message.Append("Ticket Source should start with capital alphabet and it should have minimum 3 alphabets\n");
                }
                if (trs.Type == string.Empty)
                {
                    trsValidated = false;
                    message.Append("Type should be provided");
                }
                else if (trs.Type.ToLower() != "SLEEPER" &&
                        trs.Type.ToLower() != "3ac" &&
                        trs.Type.ToLower() != "2ac" &&
                        trs.Type.ToLower() != "1AC")
                {
                    trsValidated = false;
                    message.Append("Type should be either sLEPER or 3aC or 2AC or AC\n");
                }
                //if (trs.Type == string.Empty)
                //{
                //    trsValidated= false;
                //    message.Append("Type should be provided");
                //}
                //else if (trs.Type.ToLower() != "500" &&
                //        trs.Type.ToLower() != "" &&
                //        trs.Type.ToLower() != "hyderabad" &&
                //        trs.Type.ToLower() != "bangalore")
                //{
                //    trsValidated = false;
                //    message.Append("Type should be either Pune or Mumbai or Hyderabad or Bangalore\n");
                //}
                //Checking Date of Joining
                if (trs.BookingDate != DateTime.Today)
                {
                    trsValidated = false;
                    message.Append("Date of Joining should be less than or equal to today's date");
                }
                //Checking Date of Joining
                //if (trs.DateofJourny <= DateTime.Today)
                //{
                //    trsValidated = false;
                //    message.Append("Date of Joining should be less than or equal to today's date");
                //}
                if (trsValidated == false)
                {
                    throw new Exception1(message.ToString());
                }
            }
            catch (Exception1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsValidated;
        }
        public static bool AddEmployee(TRSEntity emp)
        {
            bool empAdded = false;

            try
            {
                if (ValidateTRS(emp))
                {
                    empAdded = TRSOperations.AddTRSEntity(emp);
                }
                else
                {
                    throw new Exception1("Please provide valid data for employee");
                }
            }
            catch (Exception1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

    }

}
